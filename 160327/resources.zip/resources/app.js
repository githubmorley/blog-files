var gStageWidthLF = 9; // ステージの幅
var gStageWidth = 8; // ステージの幅
var gStageHeight = 5; // ステージの高さ
var gInputInterval = 60 * 0.5;
var gStageString =
	"WWWWWWWW\n" +
	"W GGP  W\n" +
	"W BB   W\n" +
	"W      W\n" +
	"WWWWWWWW\n";

//列挙型
if(typeof eTypeChar == "undefined") { // テキストの種類
	var eTypeChar = {};
	eTypeChar.Player = "P"; // プレイヤー
	eTypeChar.Goal = "G"; // ゴール
	eTypeChar.Wall = "W"; // 壁
	eTypeChar.Space = " "; // スペース
	eTypeChar.Block = "B"; // ブロック
};

if(typeof eMainSeq == "undefined") { // テキストの種類
	var eMainSeq = {};
	eMainSeq.Init = 1; // 初期化
	eMainSeq.Input = 2; // 入力待ち
	eMainSeq.Interval = 3; // 入力間隔
	eMainSeq.Wait = 4; // 入力待ち
};

var HelloWorldLayer = cc.Layer.extend({  // cc.Layerを継承
	joystick_:null, // ジョイスティック
	button_:null, // ボタン
	bmLabel:null, // ラベル
	arStageChar:[], // ステージの配列
	playerPos:cc.p(0, 0), // プレイヤーの座標
	playerIndex:0, // プレイヤーのインデックス
	mainSeq:0, // メインシーケンス
	countInterval:0, // 入力間隔
	goalNum:0, // 残りゴールの数
    ctor:function () { // コンストラクタ
    	this._super(); // 親クラスのメソッドを継承
    	var mainscene = ccs.load(res.MainScene_json); // MainSceneのJSONファイルを読み込む
        this.addChild(mainscene.node); // レイヤーに追加
        this.createJoyPad(); // ジョイパッドを作成
        this.bmLabel = mainscene.node.getChildByName("BitmapFontLabel"); // BitmapFontLabelを取得
        this.scheduleUpdate(); // メインループを開始
        this.mainSeq = eMainSeq.Init; // 初期化処理
        return true;
    },
    update:function(dt){ // メインループ
    	switch (this.mainSeq) { // メインシーケンスごとの処理
    	case eMainSeq.Init: // 初期化処理
    		this.arStageChar = []; // 配列を初期化
    		this.goalNum = 0; // 残りゴール数を初期化
    		for (var int = 0; int < gStageString.length; int++) { // ステージの文字数分ループ
    			var c = gStageString.substr(int, 1); // 一文字取得
    			this.arStageChar.push(c);	// 1文字ごと配列に格納
    			switch (c) { // 文字をチェック
    			case eTypeChar.Player: // プレイヤーの場合
    				this.playerPos = cc.p(int % gStageWidthLF, Math.floor(int / gStageWidthLF)); // 座標を取得
    				this.playerIndex = int; // インデックスを取得
    				break;
    			case eTypeChar.Goal: // ゴールの場合
    				this.goalNum ++; // 残りゴールの数をカウント
    				break;
    			}
    		}
    		this.bmLabel.setString(gStageString); // ラベルにステージデータを表示
    		this.mainSeq = eMainSeq.Input; // 入力処理へ移行
    		break;
		case eMainSeq.Input: // 入力処理
			if ( this.button_.getValue() == 1 ) { // ボタンが押された場合
				this.mainSeq = eMainSeq.Init; // ゲームをやり直す
			}
			// ↓参照渡しにならないように値を取得
			var velocity = cc.p(this.joystick_.getVelocity().x, this.joystick_.getVelocity().y); // ジョイスティックの値を取得
			velocity.x = Math.round(velocity.x); // 0/1の値にする
			velocity.y = -Math.round(velocity.y); // 0/1の値にし、座標を反転
			if (velocity.x + velocity.y == 0) break; // 入力がない場合処理を抜ける
			var newPos = cc.pAdd(this.playerPos, velocity); // 移動先の座標を計算
			if(newPos.x < 0 || newPos.x >= gStageWidth
					|| newPos.y < 0 || newPos.y >= gStageHeight) break; // 移動先がステージ外の場合処理を抜ける
			
			// 移動処理
			var newIndex = newPos.y * gStageWidthLF + newPos.x; //移動先のインデックスを計算
			switch (this.arStageChar[newIndex]) { // プレイヤーの移動先をチェック
			case eTypeChar.Space: // スペースの場合
				this.arStageChar[this.playerIndex] = eTypeChar.Space; // 移動元をスペースに変更
				this.arStageChar[newIndex] = eTypeChar.Player; // 移動先をプレイヤーに変更
				this.playerPos = newPos; // プレイヤーの座標を更新
				this.playerIndex = newIndex; // プレイヤーのインデックスを更新
				break;
			case eTypeChar.Wall: // 壁の場合、移動しない
				break;
			case eTypeChar.Block: // ブロックの場合
				var newPos2 = cc.pAdd(newPos, velocity); // 2マス先の座標を計算
				if(newPos2.x < 0 || newPos2.x >= gStageWidth
						|| newPos2.y < 0 || newPos2.y >= gStageHeight) break; // 2マス先がステージ外の場合処理を抜ける
				var newIndex2 = newPos2.y * gStageWidthLF + newPos2.x; //2マス先のインデックスを計算
				switch (this.arStageChar[newIndex2]) { // ブロックの移動先をチェック) {
				case eTypeChar.Goal: // ゴールの場合
					this.goalNum --; // ゴール数を減らす（breakせずスペースの場合と共通処理）
				case eTypeChar.Space: // スペースの場合
					this.arStageChar[this.playerIndex] = eTypeChar.Space; // 移動元をスペースに変更
					this.arStageChar[newIndex] = eTypeChar.Player; // プレイヤーの移動先をプレイヤーに変更
					this.arStageChar[newIndex2] = eTypeChar.Block; // ブロックの移動先をブロックに変更
					this.playerPos = newPos; // プレイヤーの座標を更新
					this.playerIndex = newIndex; // プレイヤーのインデックスを更新
					break;
				}
				break;
			}

			// ステージを描画
			var stageString = ""; //　ステージの文字列取得用
			for (var int = 0; int < this.arStageChar.length; int++) { // 文字数分ループ
				stageString += this.arStageChar[int]; // 配列から文字列に追加
			}
			if (this.goalNum == 0) { // 残りゴール数が0の場合
				stageString += "COMPLATE"; // クリア表示
				// 入力の間を開ける
				this.mainSeq = eMainSeq.Wait; // ボタンに入力待ち
			} else {
				// 入力の間を開ける
				this.mainSeq = eMainSeq.Interval; // 入力間隔処理
				this.countInterval = gInputInterval; // カウント数をセット
			}
			this.bmLabel.setString(stageString); // ラベルに表示
			break;
		case eMainSeq.Interval: // 入力間隔処理（ジョイスティックを倒し続けた場合に移動に間隔を開ける）
			if (-- this.countInterval < 1) { // カウントが完了した場合
				this.mainSeq = eMainSeq.Input; // 入力処理に移行
			} else { // カウント中
				var velocity = this.joystick_.getVelocity(); // ジョイスティックの値を取得
				if (velocity.x + velocity.y == 0){ // ジョイスティックが開放されたら
					this.mainSeq = eMainSeq.Input; // 入力処理に移行
				}
			}
			break;
		case eMainSeq.Wait: // ボタン入力待ち
			if ( this.button_.getValue() == 1 ) { // ボタンが押された場合
				this.mainSeq = eMainSeq.Init; // ゲームをやり直す
			}
		}
    },
    createJoyPad:function(){ // ジョイスティックを作成
    	var joystickSkin = new SneakyJoystickSkinnedBase(); // ジョイスティックスキンのインスタンスを作成
    	joystickSkin.setPosition(160, 120); // ジョイスティックスキンを配置
    	joystickSkin.setBackgroundSprite(new cc.Sprite(res.joystick_background_png)); // 背景部分のスプライトを設定
    	joystickSkin.setThumbSprite(new cc.Sprite(res.joystick_thumb_png)); // 親指部分のスプライトを設定
    	var joystick = new SneakyJoystick(cc.rect(0, 0, 128, 128)); // ジョイスティックのインスタンスを作成
    	joystick.setIsDPad(true); // デジタルジョイパッドを有効
    	joystick.setNumberOfDirections(4); // デジタルジョイパッドの方向数を設定
    	joystick.setHasDeadzone(true); // デッドゾーンを有効
    	joystick.setDeadRadius(32); // デッドゾーンの半径を設定
    	joystick.setAutoCenter(true); // 自動センター復帰機能を有効
    	joystickSkin.setJoystick(joystick); // ジョイスティックスキンにジョイスティックのインスタンスを渡す
    	this.addChild(joystickSkin); // 自ノードにジョイスティックスキンを追加
    	this.joystick_ = joystick; // ジョイスティックを取得
    	
    	var buttonSkin = new SneakyButtonSkinnedBase(); // ボタンスキンのインスタンスを作成
    	buttonSkin.setPosition(480, 120); // ボタンスキンを配置
    	buttonSkin.setDefaultSprite(new cc.Sprite(res.button_normal_png)); // デフォルト状態のスプライトを設定
    	buttonSkin.setPressSprite(new cc.Sprite(res.button_pressed_png)); // 押下状態のスプライトを設定
    	buttonSkin.setActivatedSprite(new cc.Sprite(res.button_disabled_png)); // 処理中状態のスプライトを設定
    	var button = new SneakyButton(cc.rect(0, 0, 64, 64)); // ボタンのインスタンスを作成
    	button.setIsHoldable(false); // ホールド機能を無効
    	button.setRateLimit(1 / 120); // ホールド機能無効時のボタンON時間を設定
    	button.setIsToggleable(false); // トグル機能を無効
    	buttonSkin.setButton(button); // ボタンスキンにボタンのインスタンスを渡す
    	this.addChild(buttonSkin); // 自ノードにボタンを追加
    	this.button_ = button; // ボタンを取得
    }
});

var HelloWorldScene = cc.Scene.extend({
    onEnter:function () {
        this._super();
        var layer = new HelloWorldLayer();
        this.addChild(layer);
    }
});

