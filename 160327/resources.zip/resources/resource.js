var res = {
		HelloWorld_png : "res/HelloWorld.png",
		MainScene_json : "res/MainScene.json",
		Plist_plist : "res/Plist.plist", // スプライトシートのplistファイルを追加
		Plist_png : "res/Plist.png" // スプライトシートのpngファイルを追加
};

var g_resources = [];
for (var i in res) {
    g_resources.push(res[i]);
}
